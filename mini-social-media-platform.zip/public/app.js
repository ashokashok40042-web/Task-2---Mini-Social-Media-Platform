const API = "/api";
let token = localStorage.getItem("circle_token");
let currentUser = null;
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function headers() {
  return { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) };
}
async function request(url, options = {}) {
  const response = await fetch(API + url, { ...options, headers: { ...headers(), ...(options.headers || {}) } });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.message || "Request failed.");
  return data;
}
function escapeHTML(value = "") {
  return String(value).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function avatar(user, sizeClass = "") {
  const letter = escapeHTML((user?.name || user?.username || "U").charAt(0).toUpperCase());
  return `<div class="avatar ${sizeClass}">${user?.avatar ? `<img src="${escapeHTML(user.avatar)}" alt="" onerror="this.remove()">` : letter}</div>`;
}
function timeAgo(date) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(date)) / 1000));
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds/60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds/3600)}h ago`;
  return `${Math.floor(seconds/86400)}d ago`;
}
function showMessage(text, target = "#globalMessage", good = false) {
  const el = $(target); el.textContent = text; el.style.color = good ? "#269b78" : "";
  setTimeout(() => { if (el.textContent === text) el.textContent = ""; }, 4500);
}
function showApp(loggedIn) {
  $("#authPanel").classList.toggle("hidden", loggedIn);
  $("#appArea").classList.toggle("hidden", !loggedIn);
  $("#logoutBtn").classList.toggle("hidden", !loggedIn);
}
function switchAuth(mode) {
  $$(".tab").forEach(b => b.classList.toggle("active", b.dataset.auth === mode));
  $("#loginForm").classList.toggle("hidden", mode !== "login");
  $("#registerForm").classList.toggle("hidden", mode !== "register");
  $("#authMessage").textContent = "";
}
$$(".tab").forEach(b => b.addEventListener("click", () => switchAuth(b.dataset.auth)));

async function authenticate(endpoint, form) {
  const body = Object.fromEntries(new FormData(form).entries());
  try {
    const data = await request(`/auth/${endpoint}`, { method: "POST", body: JSON.stringify(body) });
    token = data.token; currentUser = data.user;
    localStorage.setItem("circle_token", token);
    showApp(true); await loadMe(); await loadFeed();
  } catch (error) { showMessage(error.message, "#authMessage"); }
}
$("#loginForm").addEventListener("submit", e => { e.preventDefault(); authenticate("login", e.currentTarget); });
$("#registerForm").addEventListener("submit", e => { e.preventDefault(); authenticate("register", e.currentTarget); });
$("#logoutBtn").addEventListener("click", () => {
  token = null; currentUser = null; localStorage.removeItem("circle_token"); showApp(false);
});

function switchView(view) {
  $("#feedView").classList.toggle("hidden", view !== "feed");
  $("#profileView").classList.toggle("hidden", view !== "profile");
  $("#searchResults").classList.add("hidden");
  $$(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === view));
  if (view === "profile") loadProfile();
  if (view === "feed") loadFeed();
}
$$(".nav-item").forEach(b => b.addEventListener("click", () => switchView(b.dataset.view)));

async function loadMe() {
  currentUser = await request("/users/me");
  $("#composerAvatar").innerHTML = currentUser.avatar
    ? `<img src="${escapeHTML(currentUser.avatar)}" alt="">`
    : escapeHTML(currentUser.name.charAt(0).toUpperCase());
}
async function loadFeed() {
  try {
    const posts = await request("/posts");
    $("#feed").innerHTML = posts.length ? posts.map(renderPost).join("") : `<div class="panel empty">No posts yet. Be the first to share something!</div>`;
  } catch (error) { showMessage(error.message); }
}
function renderPost(post) {
  const liked = post.likes.some(id => String(id) === String(currentUser.id || currentUser._id));
  const own = String(post.author?._id) === String(currentUser.id || currentUser._id);
  return `<article class="panel post" data-post="${post._id}">
    <div class="post-head">${avatar(post.author)}<div class="post-author">${escapeHTML(post.author?.name || "User")}<small>@${escapeHTML(post.author?.username || "")}</small></div>
    <span class="post-date">${timeAgo(post.createdAt)}</span></div>
    ${post.caption ? `<p class="post-caption">${escapeHTML(post.caption)}</p>` : ""}
    ${post.imageUrl ? `<img class="post-image" src="${escapeHTML(post.imageUrl)}" alt="Post image" loading="lazy" onerror="this.style.display='none'">` : ""}
    <div class="post-actions"><button class="text-button ${liked ? "liked" : ""}" data-action="like">${liked ? "♥ Liked" : "♡ Like"} · <span class="likes-count">${post.likes.length}</span></button><span class="text-button">▢ ${post.comments.length} comments</span>${own ? `<button class="text-button" data-action="delete">Delete</button>` : ""}</div>
    <div class="comments">${post.comments.map(c => `<div class="comment"><strong>@${escapeHTML(c.author?.username || "user")}</strong>${escapeHTML(c.text)}</div>`).join("")}
      <form class="comment-form"><input name="text" maxlength="500" placeholder="Write a comment..." required><button class="button ghost">Send</button></form>
    </div></article>`;
}
$("#feed").addEventListener("click", async e => {
  const btn = e.target.closest("[data-action]"); if (!btn) return;
  const card = btn.closest("[data-post]"); const id = card.dataset.post;
  try {
    if (btn.dataset.action === "like") await request(`/posts/${id}/like`, { method: "POST" });
    if (btn.dataset.action === "delete" && confirm("Delete this post?")) await request(`/posts/${id}`, { method: "DELETE" });
    await loadFeed();
  } catch (error) { showMessage(error.message); }
});
$("#feed").addEventListener("submit", async e => {
  if (!e.target.matches(".comment-form")) return;
  e.preventDefault(); const id = e.target.closest("[data-post]").dataset.post;
  const text = new FormData(e.target).get("text");
  try { await request(`/posts/${id}/comments`, { method: "POST", body: JSON.stringify({ text }) }); await loadFeed(); }
  catch (error) { showMessage(error.message); }
});
$("#postForm").addEventListener("submit", async e => {
  e.preventDefault(); const body = Object.fromEntries(new FormData(e.currentTarget).entries());
  try { await request("/posts", { method: "POST", body: JSON.stringify(body) }); e.currentTarget.reset(); await loadFeed(); showMessage("Your post is live!", "#globalMessage", true); }
  catch (error) { showMessage(error.message); }
});

async function loadProfile() {
  try {
    const user = await request("/users/me");
    $("#profileCard").innerHTML = `${avatar(user)}<div><div class="profile-name">${escapeHTML(user.name)}</div><div class="profile-meta">@${escapeHTML(user.username)}</div><p>${escapeHTML(user.bio || "No bio added yet.")}</p><div class="profile-stats"><span><b>${user.followersCount}</b> followers</span><span><b>${user.followingCount}</b> following</span></div></div>`;
    const form = $("#profileForm");
    form.elements.name.value = user.name; form.elements.bio.value = user.bio || ""; form.elements.avatar.value = user.avatar || "";
  } catch (error) { showMessage(error.message); }
}
$("#profileForm").addEventListener("submit", async e => {
  e.preventDefault(); const body = Object.fromEntries(new FormData(e.currentTarget).entries());
  try { await request("/users/me", { method: "PUT", body: JSON.stringify(body) }); await loadMe(); await loadProfile(); showMessage("Profile updated.", "#globalMessage", true); }
  catch (error) { showMessage(error.message); }
});

let searchTimer;
$("#searchInput").addEventListener("input", e => {
  clearTimeout(searchTimer); const q = e.target.value.trim();
  if (!q) { $("#searchResults").classList.add("hidden"); return; }
  searchTimer = setTimeout(() => searchPeople(q), 300);
});
async function searchPeople(q) {
  try {
    const users = await request(`/users/search?q=${encodeURIComponent(q)}`);
    $("#feedView").classList.add("hidden"); $("#profileView").classList.add("hidden");
    $("#searchResults").classList.remove("hidden");
    $("#searchResults").innerHTML = `<h3>People</h3>${users.length ? users.map(u => `<div class="post-head" style="padding:12px 0;border-top:1px solid #eee">${avatar(u)}<div class="post-author">${escapeHTML(u.name)}<small>@${escapeHTML(u.username)}</small></div><button class="button ${u.isFollowing ? "ghost" : "primary"}" data-follow="${u.id}">${u.isFollowing ? "Following" : "Follow"}</button></div>`).join("") : `<p class="empty">No people found.</p>`}`;
  } catch (error) { showMessage(error.message); }
}
$("#searchResults").addEventListener("click", async e => {
  const btn = e.target.closest("[data-follow]"); if (!btn) return;
  try { await request(`/users/${btn.dataset.follow}/follow`, { method: "POST" }); await searchPeople($("#searchInput").value.trim()); }
  catch (error) { showMessage(error.message); }
});

async function init() {
  if (!token) return showApp(false);
  try { showApp(true); await loadMe(); await loadFeed(); }
  catch (_error) { token = null; localStorage.removeItem("circle_token"); showApp(false); }
}
init();
