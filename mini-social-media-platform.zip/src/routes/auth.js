const router = require("express").Router();
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const User = require("../models/User");

function makeToken(userId) {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: "7d" });
}
function publicUser(user) {
  return {
    id: user._id, name: user.name, username: user.username,
    email: user.email, bio: user.bio, avatar: user.avatar,
    followersCount: user.followers.length, followingCount: user.following.length
  };
}

router.post("/register", async (req, res, next) => {
  try {
    const { name, username, email, password } = req.body;
    if (!name || !username || !email || !password)
      return res.status(400).json({ message: "All fields are required." });
    if (password.length < 8)
      return res.status(400).json({ message: "Password must be at least 8 characters." });
    const normalizedUsername = username.toLowerCase().trim();
    const normalizedEmail = email.toLowerCase().trim();
    if (!/^[a-z0-9_]{3,20}$/.test(normalizedUsername))
      return res.status(400).json({ message: "Username must be 3–20 characters (letters, numbers or _)." });

    const exists = await User.findOne({
      $or: [{ username: normalizedUsername }, { email: normalizedEmail }]
    });
    if (exists) return res.status(409).json({ message: "Username or email already exists." });

    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({
      name: name.trim(), username: normalizedUsername,
      email: normalizedEmail, password: passwordHash
    });
    res.status(201).json({ token: makeToken(user._id), user: publicUser(user) });
  } catch (error) { next(error); }
});

router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ message: "Email and password are required." });
    const user = await User.findOne({ email: email.toLowerCase().trim() }).select("+password");
    if (!user || !(await bcrypt.compare(password, user.password)))
      return res.status(401).json({ message: "Invalid email or password." });
    res.json({ token: makeToken(user._id), user: publicUser(user) });
  } catch (error) { next(error); }
});

module.exports = router;
