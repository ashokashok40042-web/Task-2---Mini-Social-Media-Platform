const router = require("express").Router();
const Post = require("../models/Post");
const auth = require("../middleware/auth");

const populated = [
  { path: "author", select: "name username avatar" },
  { path: "comments.author", select: "name username avatar" }
];

router.get("/", auth, async (_req, res, next) => {
  try {
    const posts = await Post.find().populate(populated).sort({ createdAt: -1 }).limit(100);
    res.json(posts);
  } catch (error) { next(error); }
});

router.post("/", auth, async (req, res, next) => {
  try {
    const caption = String(req.body.caption || "").trim();
    const imageUrl = String(req.body.imageUrl || "").trim();
    if (!caption && !imageUrl) return res.status(400).json({ message: "Add a caption or image URL." });
    if (imageUrl && !/^https?:\/\/\S+$/i.test(imageUrl))
      return res.status(400).json({ message: "Image URL must start with http:// or https://." });
    const post = await Post.create({ author: req.userId, caption: caption.slice(0, 1000), imageUrl: imageUrl.slice(0, 500) });
    await post.populate(populated);
    res.status(201).json(post);
  } catch (error) { next(error); }
});

router.delete("/:id", auth, async (req, res, next) => {
  try {
    const post = await Post.findOneAndDelete({ _id: req.params.id, author: req.userId });
    if (!post) return res.status(404).json({ message: "Post not found or you are not the owner." });
    res.json({ message: "Post deleted." });
  } catch (error) { next(error); }
});

router.post("/:id/like", auth, async (req, res, next) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found." });
    const liked = post.likes.some(id => id.toString() === req.userId);
    if (liked) post.likes.pull(req.userId);
    else post.likes.addToSet(req.userId);
    await post.save();
    res.json({ liked: !liked, likesCount: post.likes.length });
  } catch (error) { next(error); }
});

router.post("/:id/comments", auth, async (req, res, next) => {
  try {
    const text = String(req.body.text || "").trim();
    if (!text) return res.status(400).json({ message: "Comment cannot be empty." });
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: "Post not found." });
    post.comments.push({ author: req.userId, text: text.slice(0, 500) });
    await post.save();
    await post.populate(populated);
    res.status(201).json(post.comments[post.comments.length - 1]);
  } catch (error) { next(error); }
});

module.exports = router;
