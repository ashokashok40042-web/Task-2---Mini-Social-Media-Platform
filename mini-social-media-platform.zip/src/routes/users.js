const router = require("express").Router();
const User = require("../models/User");
const auth = require("../middleware/auth");

const profileFields = "name username bio avatar followers following createdAt";

router.get("/me", auth, async (req, res, next) => {
  try {
    const user = await User.findById(req.userId).select(profileFields);
    if (!user) return res.status(404).json({ message: "User not found." });
    res.json({ ...user.toObject(), followersCount: user.followers.length, followingCount: user.following.length });
  } catch (error) { next(error); }
});

router.put("/me", auth, async (req, res, next) => {
  try {
    const { name, bio, avatar } = req.body;
    const updates = {};
    if (typeof name === "string" && name.trim()) updates.name = name.trim().slice(0, 60);
    if (typeof bio === "string") updates.bio = bio.trim().slice(0, 160);
    if (typeof avatar === "string") updates.avatar = avatar.trim().slice(0, 500);
    const user = await User.findByIdAndUpdate(req.userId, updates, { new: true, runValidators: true }).select(profileFields);
    res.json({ ...user.toObject(), followersCount: user.followers.length, followingCount: user.following.length });
  } catch (error) { next(error); }
});

router.get("/search", auth, async (req, res, next) => {
  try {
    const q = String(req.query.q || "").trim();
    if (!q) return res.json([]);
    const users = await User.find({
      _id: { $ne: req.userId },
      $or: [
        { username: { $regex: q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), $options: "i" } },
        { name: { $regex: q.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), $options: "i" } }
      ]
    }).select("name username bio avatar followers").limit(10);
    res.json(users.map(u => ({
      id: u._id, name: u.name, username: u.username, bio: u.bio,
      avatar: u.avatar, followersCount: u.followers.length,
      isFollowing: u.followers.some(id => id.toString() === req.userId)
    })));
  } catch (error) { next(error); }
});

router.get("/:id", auth, async (req, res, next) => {
  try {
    const user = await User.findById(req.params.id).select(profileFields);
    if (!user) return res.status(404).json({ message: "User not found." });
    res.json({
      id: user._id, name: user.name, username: user.username, bio: user.bio,
      avatar: user.avatar, followersCount: user.followers.length,
      followingCount: user.following.length,
      isFollowing: user.followers.some(id => id.toString() === req.userId),
      isMe: user._id.toString() === req.userId
    });
  } catch (error) { next(error); }
});

router.post("/:id/follow", auth, async (req, res, next) => {
  try {
    if (req.params.id === req.userId) return res.status(400).json({ message: "You cannot follow yourself." });
    const target = await User.findById(req.params.id);
    const me = await User.findById(req.userId);
    if (!target || !me) return res.status(404).json({ message: "User not found." });

    const alreadyFollowing = target.followers.some(id => id.toString() === req.userId);
    if (alreadyFollowing) {
      target.followers.pull(req.userId);
      me.following.pull(req.params.id);
    } else {
      target.followers.addToSet(req.userId);
      me.following.addToSet(req.params.id);
    }
    await Promise.all([target.save(), me.save()]);
    res.json({ isFollowing: !alreadyFollowing, followersCount: target.followers.length });
  } catch (error) { next(error); }
});

module.exports = router;
