# Circle — Mini Social Media Platform

A responsive mini social media application built with **HTML, CSS, JavaScript, Node.js, Express.js and MongoDB**.

## Features

- User registration and login
- Secure password hashing with bcrypt
- JWT-based authentication
- User profiles with editable name, bio and avatar URL
- Create posts with captions and optional image URLs
- View the latest posts in a home feed
- Like and unlike posts
- Add comments to posts
- Search for users by name or username
- Follow and unfollow users
- Delete your own posts
- Responsive layout for desktop and mobile

## Tech stack

| Layer | Technology |
|---|---|
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Backend | Node.js, Express.js |
| Database | MongoDB with Mongoose |
| Authentication | JSON Web Token (JWT), bcryptjs |
| Basic security | Helmet, CORS, login rate limiting |

## Project structure

```text
mini-social-media-platform/
├── public/
│   ├── app.js
│   ├── index.html
│   └── styles.css
├── src/
│   ├── middleware/
│   │   └── auth.js
│   ├── models/
│   │   ├── Post.js
│   │   └── User.js
│   └── routes/
│       ├── auth.js
│       ├── posts.js
│       └── users.js
├── .env.example
├── .gitignore
├── package.json
├── README.md
└── server.js
```

## Requirements

- Node.js 18 or later
- npm
- MongoDB Community Server running locally, or a MongoDB Atlas connection string

## Installation and setup

1. Extract the project ZIP and open the folder in VS Code.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Create a `.env` file by copying `.env.example`.
4. Update `MONGODB_URI` and set a long, random `JWT_SECRET` in `.env`.
5. Start MongoDB if you are using a local database.
6. Start the application:

   ```bash
   npm start
   ```

7. Open **http://localhost:5000** in your browser.
8. Create an account and test the features. Create a second account in another browser/incognito session to test following.

## API overview

All protected routes require:

```http
Authorization: Bearer YOUR_JWT_TOKEN
```

### Authentication

| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/register` | Create an account |
| POST | `/api/auth/login` | Log in |

### Users

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/users/me` | Get your profile |
| PUT | `/api/users/me` | Update your profile |
| GET | `/api/users/search?q=name` | Search users |
| GET | `/api/users/:id` | View a user profile |
| POST | `/api/users/:id/follow` | Follow or unfollow a user |

### Posts

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/posts` | Get the feed |
| POST | `/api/posts` | Create a post |
| DELETE | `/api/posts/:id` | Delete your own post |
| POST | `/api/posts/:id/like` | Like or unlike a post |
| POST | `/api/posts/:id/comments` | Add a comment |

## Database collections

- **users**: name, username, email, password hash, bio, avatar, followers and following
- **posts**: author, caption, image URL, likes and embedded comments

## GitHub upload

1. Create a new repository on GitHub, for example `mini-social-media-platform`.
2. Extract this ZIP.
3. Open the extracted folder in VS Code.
4. Initialize Git and push:

   ```bash
   git init
   git add .
   git commit -m "Build mini social media platform"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/mini-social-media-platform.git
   git push -u origin main
   ```

Do not upload your `.env` file or share your JWT secret. The `.gitignore` file excludes `.env` and `node_modules`.

## Internship submission description

**Project Title:** Mini Social Media Platform

**Description:** Developed a responsive social media web application that allows users to create accounts, manage profiles, publish posts, comment, like posts, search for people, and follow or unfollow users. The frontend uses HTML, CSS and JavaScript, while Express.js provides REST API endpoints and MongoDB stores user and post data. Passwords are hashed and protected routes use JWT authentication.

## Notes

- This is an educational internship project starter, not a production-ready social network.
- Profile and post images are supplied as public image URLs; file upload is not included.
- Before public deployment, add stronger validation, account recovery, privacy controls, moderation/reporting, secure cookie-based token handling, HTTPS, and automated tests.
